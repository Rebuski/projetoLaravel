<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DisciplinaUser extends Model {

    protected $table = 'disciplina_user';

}
