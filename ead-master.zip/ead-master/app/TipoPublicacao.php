<?php

namespace App;

/**
 * Tipos de publicacao
 */
abstract class TipoPublicacao {

    const SECAO = 0;
    const POSTAGEM = 1;
    const TAREFA = 2;

}
