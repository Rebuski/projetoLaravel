<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TarefaUser extends Model {

    protected $table = 'tarefa_user';

}
